from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from .models import Income

class IncomeAPITestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.income_data = {'amount': 1000, 'description': 'Salary'}

    def test_create_income(self):
        response = self.client.post('/api/incomes/', self.income_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Income.objects.count(), 1)
        self.assertEqual(Income.objects.first().amount, 1000)

    def test_get_incomes(self):
        response = self.client.get('/api/incomes/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
