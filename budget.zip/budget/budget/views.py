from django.shortcuts import render
from rest_framework import viewsets
from .models import Income, Expense, Budget
from .serializers import IncomeSerializer, ExpenseSerializer, BudgetSerializer


class IncomeViewSet(viewsets.ModelViewSet):
    queryset = Income.objects.all()
    serializer_class = IncomeSerializer

class ExpenseViewSet(viewsets.ModelViewSet):
    queryset = Expense.objects.all()
    serializer_class = ExpenseSerializer

class BudgetViewSet(viewsets.ModelViewSet):
    queryset = Budget.objects.all()
    serializer_class = BudgetSerializer



def dashboard(request):
    incomes = Income.objects.filter(user=request.user)
    expenses = Expense.objects.filter(user=request.user)

    total_income = sum([income.amount for income in incomes]) or 0
    total_expense = sum([expense.amount for expense in expenses]) or 0

    budget_data = {
        'total_income': total_income,
        'total_expense': total_expense,
    }

    return render(request, 'dashboard.html', {
        'budget_data': budget_data,
    })


